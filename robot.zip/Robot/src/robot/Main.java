// ==========================================================================
// $Id: Main.java,v 1.4 2016/10/14 02:34:29 jlang Exp $
// ELG5124/CSI5151 Robot Arm Kinematics
// ==========================================================================
// (C)opyright:
//
//   Jochen Lang
//   EECS, University of Ottawa
//   800 King Edward Ave.
//   Ottawa, On., K1N 6N5
//   Canada. 
//   http://www.eecs.uottawa.ca
// 
// Creator: jlang (Jochen Lang)
// Email:   jlang@eecs.uottawa.ca
// ==========================================================================
// $Log: Main.java,v $
// ==========================================================================
package robot;

import com.jme3.app.SimpleApplication;
import com.jme3.input.KeyInput;
import com.jme3.input.controls.ActionListener;
import com.jme3.input.controls.KeyTrigger;
import com.jme3.material.Material;
import com.jme3.math.ColorRGBA;
import com.jme3.math.Vector3f;
import com.jme3.math.Matrix3f;
import com.jme3.math.Quaternion;
import com.jme3.math.Eigen3f;
import com.jme3.scene.Geometry;
import com.jme3.scene.shape.Sphere;
import com.jme3.system.AppSettings;
import com.jme3.scene.shape.Line;
import com.jme3.scene.Mesh;
import com.jme3.scene.VertexBuffer.Type;
import com.jme3.util.BufferUtils;
import com.jme3.input.controls.AnalogListener;
import com.jme3.material.RenderState.BlendMode;
import com.jme3.renderer.queue.RenderQueue;
import com.jme3.scene.Node;
import com.jme3.scene.shape.Box;

public class Main extends SimpleApplication {

    private Geometry line;
    private Geometry target;
    private Node sObject;
            
    public static void main(String[] args) {
        Main app = new Main();
        // app.setShowSettings(false);
        AppSettings settings = new AppSettings(true);
        /*
        settings.put("Width", 640);
        settings.put("Height", 480);
        */
        settings.put("Title", "ELG5124 Robot Arm");
        // VSynch
        // settings.put("VSync", true)
        // Anti-Aliasing
        // settings.put("Samples", 4);
        // Initialize sphere control        
        app.setSettings(settings);
        app.start();
    }
    
    private Vector3f startP; 
    private Vector3f endP;
    Vector3f [] vertices;

    /**
     * Simple analoglistener which takes the camera-based directions and adds it
     * to the local translation of the target. Implicitly assumes that the target is
     * directly attached to scene root.
     */
    final private AnalogListener analogListener;

    
    private final ActionListener actionListener;

    
    public Main() {
        this.actionListener = new ActionListener() {    
            @Override
            public void onAction(String name, boolean keyPressed, float tpf) {
                if (name.equals("Next") && !keyPressed) {
                    // Ray from target position at last time step to current.
                    // Reset our line drawing
                    startP.set(endP);
                    // and redraw
                    updateLine();
                }
            }
        };
        
        this.analogListener = new AnalogListener() {
            @Override
            public void onAnalog(String name, float value, float tpf) {
                value *= 10.0;
                // find forward/backward direction and scale it down
                Vector3f camDir = cam.getDirection().clone().multLocal(value);
                // find right/left direction
                Vector3f camLeft = cam.getLeft().clone().multLocal(value);
                // find up/down direction
                Vector3f camUp = cam.getUp().clone().multLocal(value);
                boolean pChange = false;
                if (name.equals("Left")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camLeft));
                    pChange = true;
                }
                if (name.equals("Right")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camLeft.negateLocal()));
                    pChange = true;
                }
                if (name.equals("Forward")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camDir));
                    pChange = true;
                }
                if (name.equals("Back")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camDir.negateLocal()));
                    pChange = true;
                }
                if (name.equals("Up")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camUp));
                    pChange = true;
                }
                if (name.equals("Down")) {
                    Vector3f v = target.getLocalTranslation();
                    target.setLocalTranslation(v.add(camUp.negateLocal()));
                    pChange = true;
                }
                if (pChange) updateLine();
            }
        };
    }

    @Override
    public void simpleInitApp() {
        // Left mouse button press to rotate camera
        flyCam.setDragToRotate(true);
        // Do not display stats or fps
        setDisplayFps(false);
        setDisplayStatView(false);
        // move the camera back (10 is the default)
        // cam.setLocation(new Vector3f(0f, 0f, 5.0f));
        // also: cam.setRotation(Quaternion)

        
        // Generate the robot - starting with a box for the base
        sObject = new Node();
        Geometry base = new Geometry("Base", new Box(0.5f, 0.5f, 0.5f));
        base.setLocalTranslation(-3.5f, -2.5f, 0.0f);
        Material matBase = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        // Use transparency - just to make sure we can always see the target
        matBase.setColor("Color", new ColorRGBA( 0.7f, 0.7f, 0.7f, 0.5f)); // silver'ish
        matBase.getAdditionalRenderState().setBlendMode(BlendMode.Alpha);
        base.setMaterial(matBase);
        base.setQueueBucket(RenderQueue.Bucket.Transparent);
        
        sObject.attachChild(base);
        rootNode.attachChild(sObject);
        
        // Generate a sphere as a symbol for the target point
        target = new Geometry("Sphere", new Sphere(6, 12, 0.1f));
        Material matSphere = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        matSphere.setColor("Color", ColorRGBA.Red);
        target.setMaterial(matSphere);

        rootNode.attachChild(target);

        // Set up line drawing from last position to current position of target
        // We artifically create a time step based on the number of interactions
        startP = new Vector3f(target.getLocalTranslation());
        endP = new Vector3f(target.getLocalTranslation()); 
        vertices = new Vector3f[]{startP,endP};
        Line ln = new Line(startP,endP);
        ln.setLineWidth(2);
        line = new Geometry("line", ln);
        Material mat = new Material(assetManager, "Common/MatDefs/Misc/Unshaded.j3md");
        mat.setColor("Color", ColorRGBA.Green);
        line.setMaterial(mat);
        
        rootNode.attachChild(line);

        /** Set up interaction keys */
        setUpKeys();

        // Can be used to change mapping of mouse/keys to camera behaviour
        /*
         if (inputManager != null) {
         inputManager.deleteMapping("FLYCAM_RotateDrag");
         flyCam.setDragToRotate(true);
         inputManager.addMapping("FLYCAM_RotateDrag", new MouseButtonTrigger(MouseInput.BUTTON_RIGHT));
         inputManager.addListener(flyCam, "FLYCAM_RotateDrag");
         }
         */
    }

    private void setUpKeys() {
        inputManager.addMapping("Left", new KeyTrigger(KeyInput.KEY_LEFT));
        inputManager.addMapping("Right", new KeyTrigger(KeyInput.KEY_RIGHT));
        inputManager.addMapping("Up", new KeyTrigger(KeyInput.KEY_UP));
        inputManager.addMapping("Down", new KeyTrigger(KeyInput.KEY_DOWN));
        inputManager.addMapping("Forward", new KeyTrigger(KeyInput.KEY_PGUP));
        inputManager.addMapping("Back", new KeyTrigger(KeyInput.KEY_PGDN));
        inputManager.addListener(analogListener,
                "Left", "Right", "Up", "Down", "Forward", "Back");
        inputManager.addMapping("Next", new KeyTrigger(KeyInput.KEY_SPACE));
        inputManager.addListener(actionListener, "Next");
    }
       
    // Helper routine to update line
    void updateLine() {
        Mesh m = line.getMesh();
        endP.set(target.getLocalTranslation());
        m.setBuffer(Type.Position, 3, BufferUtils.createFloatBuffer(vertices));
        m.updateBound();
        
        // Tutorial section on how to use the Jama package
        java.util.Random rand = new java.util.Random();
        double[][] dm = new double[3][3];
        for ( int r=0; r<3; r++) {
            if (r!=1) { // make it singular
                for ( int c=0; c<3; c++) {
                    dm[r][c] = rand.nextFloat();
                }
            }
        }
        Jama.Matrix jm3 = new Jama.Matrix(dm);
        Jama.SingularValueDecomposition svd = new Jama.SingularValueDecomposition(jm3);
        double[] s = svd.getSingularValues();
        for ( double e:s) {
            System.out.print(e + " ");
        }
        System.out.println();
    }    
    
    // Update the position every sec
    @Override
    public void simpleUpdate(float tpf) {
    }
}
